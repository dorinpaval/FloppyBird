﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;
using FlappyBird.Properties;

namespace FlappyBird
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<int> Perete1 = new List<int>();
        List<int> Perete2 = new List<int>();
        int latper = 55;   //latime
        int difY = 190;     //difer dintre pereti sus jos
        int difX = 220;      // -II- unul dupa altul; 
        bool start = true;
        bool running;
        int pas = 5; //viteza
        int OriginalX, OriginalY;  // poz initiala a lui bird
        bool Reset = false;  //cand reincepe jocul
        int Puncte;     //pozitia lui bird
        bool inperete = false;  // true cand se afla intre 2 pereti
        int scor;   //in functie de puncte
        int DifScor;


        private void Form1_Load(object sender, EventArgs e)
        {
            OriginalX = pictureBox1.Location.X;
            OriginalY = pictureBox1.Location.Y;
            if (!File.Exists("Scor.txt"))
            {
                File.Create("Scor.txt").Dispose();
            }


        }

        private void Lost()
        {
            running = false;
            timer2.Enabled = false; 
            timer3.Enabled = false;
            button1.Visible = true; //afisam si putem accesa butoanele
            button1.Enabled = true;
            button2.Visible = true;
            button2.Enabled = true;
            ArataScor();
            Puncte = 0;
            pictureBox1.Location = new Point(OriginalX, OriginalY);
            Reset = true;   //resetam peretii ca sa nu reluam de unde am ramas
            Perete1.Clear(); // stergem conductele
        }

        private void ArataScor()
        {
            using (StreamReader reader = new StreamReader("Scor.txt")) //citim din fisier
            {
                scor = int.Parse(reader.ReadToEnd()); //converteste string to no(400)
                reader.Close();
                if (int.Parse(label1.Text) == 0 | int.Parse(label1.Text) > 0)
                {
                    DifScor = scor - int.Parse(label1.Text) + 1;  // peretii pana depaseam highscore
                }

                // nou HighScore
                if (scor < int.Parse(label1.Text))
                {
                    MessageBox.Show(string.Format("Felicitari! Ai facut un scor mai mare decat {0} ! Noul HighScore este {1}", scor, label1.Text), "Flappy Bird", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    using (StreamWriter writer = new StreamWriter("Scor.txt"))
                    {
                        writer.Write(label1.Text);
                        writer.Close();
                    }

                }

                //mai putin decat Highscore

                if (scor > int.Parse(label1.Text))
                {
                    MessageBox.Show(string.Format("Iti mai trebuia {0} ca sa depasesti scorul maxim de {1}", DifScor, scor), "Flappy Bird", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                //Scor = HighScore

                if (scor == int.Parse(label1.Text))
                {
                    MessageBox.Show(string.Format("Ai facut exact scorul maxim ! ", "Flappy Bird", MessageBoxButtons.OK, MessageBoxIcon.Information));
                }
            }
        }


        private void StartJoc()
        {
            Reset = false;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;

            //pentru crearea dimensiunilor peretilor sus si jos
            Random random = new Random();
            int nr = random.Next(40, this.Height - difY);
            int nr1 = nr + difY;
            Perete1.Clear();
            Perete1.Add(this.Width);
            Perete1.Add(nr);
            Perete1.Add(this.Width);
            Perete1.Add(nr1);


            nr = random.Next(40, (this.Height - difY));
            nr1 = nr + difY;
            Perete2.Clear();
            Perete2.Add(this.Width + difX);
            Perete2.Add(nr);
            Perete2.Add(this.Width + difX);
            Perete2.Add(nr1);

            //ascundem butoanele
            button1.Visible = false;
            button1.Enabled = false;
            button2.Visible = false;
            button2.Enabled = false;
            running = true;
            Focus(); //focusam pe form

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartJoc();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (Perete1[0] + latper <= 0 | start == true)
            {
                Random rnd = new Random();
                int px = this.Width;
                int py = rnd.Next(40, (this.Height - difY));
                int p2x = px;
                int p2y = py + difY;
                
                Perete1.Clear();

                Perete1.Add(px); //latime
                Perete1.Add(py);    //lungime
                Perete1.Add(p2x);
                Perete1.Add(p2y);
            }

            else
            {
                Perete1[0] = Perete1[0] - 2;  //putem seta dificultatea
                Perete1[2] = Perete1[2] - 2;
            }

            if (Perete2[0] + latper <= 0)
            {
                Random rnd = new Random();
                int px = this.Width;
                int py = rnd.Next(40, (this.Height - difY));
                int p2x = px;
                int p2y = py + difY;
                int[] p1 = { px, py, p2x, p2y };
                Perete2.Clear();

                Perete2.Add(px);
                Perete2.Add(py);
                Perete2.Add(p2x);
                Perete2.Add(p2y);
            }

            else
            {
                Perete2[0] = Perete2[0] - 2;
                Perete2[2] = Perete2[2] - 2;
            }

            if (start == true)
            {
                start = false; //pentru a putea aceasta functie
            }


        }

        private void CheckIzbit()
        {
            Rectangle rec = pictureBox1.Bounds; //incadreaza pasarea intr-un dreptunghi
            Rectangle rec1 = new Rectangle(Perete1[0], 0, latper, Perete1[1]);
            Rectangle rec2 = new Rectangle(Perete1[2], Perete1[3], latper, this.Height - Perete1[3]);
            Rectangle rec3 = new Rectangle(Perete2[0], 0, latper, Perete2[1]);
            Rectangle rec4 = new Rectangle(Perete2[2], Perete2[3], latper, this.Height - Perete2[3]);

            Rectangle inter1 = Rectangle.Intersect(rec, rec1);
            Rectangle inter2 = Rectangle.Intersect(rec, rec2);
            Rectangle inter3 = Rectangle.Intersect(rec, rec3);
            Rectangle inter4 = Rectangle.Intersect(rec, rec4);

            if (!Reset | start)
            {
                if (inter1 != Rectangle.Empty | inter2 != Rectangle.Empty | inter3 != Rectangle.Empty | inter4 != Rectangle.Empty)
                {
                    SoundPlayer sunet = new SoundPlayer(FlappyBird.Properties.Resources.ciocnire);
                    sunet.Play();
                    Lost();
                }
            }
        } 


        private void CheckForPoint()
        {
            Rectangle rec = pictureBox1.Bounds; //pune pasarea intr-un dreptunghi
            Rectangle rec1 = new Rectangle(Perete1[2] + 20, Perete1[3] - difY, 15, difY);
            Rectangle rec2 = new Rectangle(Perete2[2] + 20, Perete2[3] - difY, 15, difY);
            Rectangle intersect1 = Rectangle.Intersect(rec, rec1);
            Rectangle intersect2 = Rectangle.Intersect(rec, rec2);

            if (!Reset | start)
            {
                if (intersect1 != Rectangle.Empty | intersect2 != Rectangle.Empty) //coliziune
                {
                    if (!inperete)
                    {
                        Puncte++;
                        SoundPlayer sunet = new SoundPlayer(FlappyBird.Properties.Resources.punct);
                        sunet.Play();
                        inperete = true; //poate trece !
                    }
                }
                else
                {
                    inperete = false; // nu poate trece
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (!Reset && Perete1.Any() && Perete2.Any()) //daca exista pereti
            {
                //prima de sus
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete1[0], 0, latper, Perete1[1])); //locatie lungime latime
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete1[0] - 10, Perete1[3] - difY, 75, 15));  //buza peretelui

                //prima de jos
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete1[2], Perete1[3], latper, this.Height - Perete1[3]));
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete1[2] - 10, Perete1[3], 75, 15));

                //a doua de sus
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete2[0], 0, latper, Perete2[1]));
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete2[0] - 10, Perete2[3] - difY, 75, 15));

                //a doua de jos
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete2[2], Perete2[3], latper, this.Height - Perete2[3]));
                e.Graphics.FillRectangle(Brushes.DarkGreen, new Rectangle(Perete2[2] - 10, Perete2[3], 75, 15));
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    pas = -5;
                    pictureBox1.Image = Resources.drept;
                    break;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + pas);

            //conditionam ca pasarea sa ramana in form
            if (pictureBox1.Location.Y < 0)
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, 0);
            }

            if (pictureBox1.Location.Y + pictureBox1.Height > this.ClientSize.Height)
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, this.ClientSize.Height - pictureBox1.Height);
            }

            CheckIzbit();

            if (running)
            {
                CheckForPoint();
            }

            label1.Text = Convert.ToString(Puncte);
        }


        //cand tasta C nu este apasata
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    pas = 5;
                    pictureBox1.Image = Resources.coboara;
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (StreamReader read = new StreamReader("scor.txt"))
            {
                MessageBox.Show(string.Format("Scorul cel mai mare este  {0} !", read.ReadLine() ), "Flappy Bird", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Invalidate(); //revalideaza functia de scriere a formei cand ajunge la 1 (intervalul timer-ului)
        }
    }
}
