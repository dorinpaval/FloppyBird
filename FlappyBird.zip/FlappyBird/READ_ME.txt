Folderul "Setup" contine fisierele necesare instalarii aplicatiei

Documentul DocumentatieFloppy.pdf contine detaliile amanuntite ale proiectului

Folderul "FlappyBird" contine aplicatia propriu-zisa dezvoltata in C#, avand in folderul
"bin/Debug" formatul executabil al aplicatiei: fisierul "FlappyBird" .

Dupa pornirea aplicatiei actionati tasta "Up" pentru a ridica pasarea.